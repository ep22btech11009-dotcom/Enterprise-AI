"""
rag/rag_engine.py — Document retrieval with LlamaIndex + OpenAI.

Uses OpenAI embeddings (text-embedding-3-small) and GPT-4o as the LLM
via llama-index-llms-openai and llama-index-embeddings-openai.
"""
import os
from config import DOCS_DIR, OPENAI_API_KEY, MODEL

_llama_loaded = False


def _load_llama():
    global _llama_loaded
    if _llama_loaded:
        return
    try:
        from llama_index.core import Settings
        from llama_index.llms.openai import OpenAI as LlamaOpenAI
        from llama_index.embeddings.openai import OpenAIEmbedding

        Settings.llm = LlamaOpenAI(
            model=MODEL,
            api_key=OPENAI_API_KEY,
            max_tokens=1024,
        )
        Settings.embed_model = OpenAIEmbedding(
            model="text-embedding-3-small",
            api_key=OPENAI_API_KEY,
        )
        _llama_loaded = True
    except ImportError as e:
        raise ImportError(
            "LlamaIndex OpenAI packages missing.\n"
            "Run: pip install -r requirements.txt\n"
            f"Detail: {e}"
        )


class RAGEngine:
    """
    Indexes enterprise documents and answers retrieval-augmented questions.
    Documents in sample_docs/ are indexed on first use (in-memory vector store).
    """

    def __init__(self):
        _load_llama()
        from llama_index.core import SimpleDirectoryReader, VectorStoreIndex

        print("  [RAGEngine] Indexing documents from:", DOCS_DIR)
        documents = SimpleDirectoryReader(DOCS_DIR).load_data()
        self._index = VectorStoreIndex.from_documents(documents)
        self._query_engine = self._index.as_query_engine(similarity_top_k=3)
        print(f"  [RAGEngine] Indexed {len(documents)} document(s).")

    def query(self, question: str) -> str:
        """Retrieve relevant passages and generate a grounded answer."""
        response = self._query_engine.query(question)
        return str(response)

    def retrieve_raw(self, question: str, top_k: int = 3) -> list:
        """Return raw retrieved chunks without generation (for debugging)."""
        retriever = self._index.as_retriever(similarity_top_k=top_k)
        nodes = retriever.retrieve(question)
        return [
            {
                "score": round(float(n.score), 4) if n.score else None,
                "text": n.get_content()[:400] + "...",
                "source": n.metadata.get("file_name", "unknown"),
            }
            for n in nodes
        ]
