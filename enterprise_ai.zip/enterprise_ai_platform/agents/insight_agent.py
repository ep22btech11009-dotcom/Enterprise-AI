"""
agents/insight_agent.py — Converts raw agent outputs into business-friendly explanations.
"""
from openai import OpenAI
from config import OPENAI_API_KEY, MODEL, MAX_TOKENS


class InsightAgent:
    """
    The final layer in the pipeline. Takes raw structured data from all other agents
    and uses GPT-4o to synthesize a clear, actionable business narrative.
    """

    def __init__(self):
        self._client = OpenAI(api_key=OPENAI_API_KEY)

    def synthesize(
        self,
        query: str,
        data_summary: dict = None,
        analysis_results: dict = None,
        ml_results: dict = None,
        rag_context: str = None,
        roi_results: dict = None,
    ) -> str:
        """
        Accepts outputs from all agents and generates a unified insight.
        Only passes non-None sections to keep prompts lean.
        """
        sections = [f"User Query: {query}\n"]

        if data_summary:
            sections.append(f"=== Data Summary ===\n{data_summary}\n")
        if analysis_results:
            sections.append(f"=== Analysis Results ===\n{analysis_results}\n")
        if ml_results:
            sections.append(f"=== ML Model Results ===\n{ml_results}\n")
        if rag_context:
            sections.append(f"=== Policy / Document Context (RAG) ===\n{rag_context}\n")
        if roi_results:
            sections.append(f"=== ROI Quantification ===\n{roi_results}\n")

        full_context = "\n".join(sections)

        system_prompt = """You are an expert enterprise analytics consultant.
Your job is to synthesize outputs from multiple AI agents into a clear,
actionable business insight. Always:
1. Start with the most critical finding.
2. Back every claim with a specific number from the data.
3. End with 2-3 concrete recommended actions.
4. Use plain business English. No jargon, no filler.
Keep responses under 300 words."""

        response = self._client.chat.completions.create(
            model=MODEL,
            max_tokens=MAX_TOKENS,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": full_context},
            ],
        )
        return response.choices[0].message.content
