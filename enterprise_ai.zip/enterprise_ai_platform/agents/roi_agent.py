"""
agents/roi_agent.py — Quantifies revenue impact, cost savings, and risk reduction.
The platform's key differentiator: translates AI outputs into business value.
"""
from openai import OpenAI
from config import OPENAI_API_KEY, MODEL, MAX_TOKENS


class ROIAgent:
    """
    Takes structured outputs from ML/Analysis agents and uses GPT-4o
    to generate business-language ROI narratives with specific dollar amounts.
    """

    def __init__(self):
        self._client = OpenAI(api_key=OPENAI_API_KEY)

    # ── Revenue Impact ──────────────────────────────────────────────────────

    def quantify_churn_roi(self, churn_predictions: list) -> dict:
        """
        Given churn predictions, compute:
        - Total ARR at risk
        - Estimated retention cost
        - Net ROI of running retention campaign
        """
        high_risk = [c for c in churn_predictions if c["risk_level"] == "HIGH"]
        total_arr_at_risk = sum(c["annual_revenue_at_risk"] for c in high_risk)

        # Retention cost: $150 per high-risk customer (specialist time + offer)
        retention_cost_per_customer = 150.0
        total_retention_cost = len(high_risk) * retention_cost_per_customer

        # Assume 60% retention success rate (per SOP)
        retention_success_rate = 0.60
        recovered_revenue = total_arr_at_risk * retention_success_rate
        net_roi = recovered_revenue - total_retention_cost

        return {
            "high_risk_customers": len(high_risk),
            "total_arr_at_risk": round(total_arr_at_risk, 2),
            "retention_campaign_cost": round(total_retention_cost, 2),
            "estimated_recovered_revenue": round(recovered_revenue, 2),
            "net_roi": round(net_roi, 2),
            "roi_multiple": round(net_roi / total_retention_cost, 2) if total_retention_cost else 0,
        }

    def quantify_fraud_roi(self, anomalies: list) -> dict:
        """
        Given detected fraud anomalies, estimate:
        - Fraud loss prevented
        - Investigation cost
        - Net savings
        """
        total_fraud_amount = sum(a["amount"] for a in anomalies)
        true_positive_rate = 0.70
        fraud_prevented = total_fraud_amount * true_positive_rate
        investigation_cost = len(anomalies) * 75 * 2
        net_savings = fraud_prevented - investigation_cost

        return {
            "anomalies_detected": len(anomalies),
            "total_flagged_amount": round(total_fraud_amount, 2),
            "estimated_fraud_prevented": round(fraud_prevented, 2),
            "investigation_cost": round(investigation_cost, 2),
            "net_savings": round(net_savings, 2),
            "risk_reduction_pct": round(true_positive_rate * 100, 1),
        }

    # ── LLM-powered narrative ───────────────────────────────────────────────

    def generate_roi_narrative(self, roi_data: dict, context: str = "") -> str:
        """Uses GPT-4o to turn raw ROI numbers into an executive-ready narrative."""
        prompt = f"""You are a senior business analyst. Given the following ROI data
from our AI analytics platform, write a concise 3-paragraph executive summary.

Be specific with numbers. Use business language (ARR, MRR, ROI multiple).
Mention the action recommended. Keep it under 200 words.

Context: {context}

ROI Data:
{roi_data}
"""
        response = self._client.chat.completions.create(
            model=MODEL,
            max_tokens=MAX_TOKENS,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content
