"""
agents/data_agent.py — Loads and queries structured CSV data.
"""
import pandas as pd
from config import CUSTOMERS_CSV, TRANSACTIONS_CSV


class DataAgent:
    """
    Loads CSV data and answers structured queries about customers
    and transactions. Returns clean DataFrames or summary dicts.
    """

    def __init__(self):
        self.customers: pd.DataFrame = pd.read_csv(CUSTOMERS_CSV)
        self.transactions: pd.DataFrame = pd.read_csv(TRANSACTIONS_CSV)
        print("  [DataAgent] Loaded customers:", len(self.customers),
              "| transactions:", len(self.transactions))

    # ── Public API ──────────────────────────────────────────────────────────

    def get_all_customers(self) -> pd.DataFrame:
        return self.customers.copy()

    def get_all_transactions(self) -> pd.DataFrame:
        return self.transactions.copy()

    def get_customer(self, customer_id: str) -> dict:
        row = self.customers[self.customers["customer_id"] == customer_id]
        if row.empty:
            return {}
        return row.iloc[0].to_dict()

    def get_transactions_for_customer(self, customer_id: str) -> pd.DataFrame:
        return self.transactions[
            self.transactions["customer_id"] == customer_id
        ].copy()

    def get_flagged_transactions(self) -> pd.DataFrame:
        return self.transactions[self.transactions["flagged"] == 1].copy()

    def get_high_value_customers(self, min_spend: float = 300.0) -> pd.DataFrame:
        return self.customers[
            self.customers["monthly_spend"] >= min_spend
        ].copy()

    def summary(self) -> dict:
        return {
            "total_customers": len(self.customers),
            "total_transactions": len(self.transactions),
            "flagged_transactions": int(self.transactions["flagged"].sum()),
            "avg_monthly_spend": round(self.customers["monthly_spend"].mean(), 2),
            "churned_customers": int(self.customers["churned"].sum()),
        }
