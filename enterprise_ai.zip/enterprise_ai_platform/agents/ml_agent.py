"""
agents/ml_agent.py — Churn prediction, fraud scoring, demand forecasting.
Uses scikit-learn with lightweight models suitable for demo data.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from config import CHURN_RISK_THRESHOLD


class MLAgent:
    """
    Trains and runs ML models on data provided by DataAgent.
    All models are trained at runtime on the sample data (no saved weights).
    """

    def __init__(self):
        self._churn_model: RandomForestClassifier | None = None
        self._churn_scaler: StandardScaler | None = None
        self._fraud_model: IsolationForest | None = None
        self._fraud_scaler: StandardScaler | None = None

    # ── Churn Prediction ────────────────────────────────────────────────────

    def train_churn_model(self, customers: pd.DataFrame) -> dict:
        """Train Random Forest churn classifier."""
        features = ["age", "tenure_months", "monthly_spend",
                    "support_tickets", "last_login_days"]
        X = customers[features].values
        y = customers["churned"].values

        self._churn_scaler = StandardScaler()
        X_scaled = self._churn_scaler.fit_transform(X)

        # Small dataset: use all data for training, report on full set
        self._churn_model = RandomForestClassifier(
            n_estimators=100, random_state=42, max_depth=4
        )
        self._churn_model.fit(X_scaled, y)

        preds = self._churn_model.predict(X_scaled)
        report = classification_report(y, preds, output_dict=True, zero_division=0)

        importances = dict(zip(features, [
            round(float(i), 4)
            for i in self._churn_model.feature_importances_
        ]))

        return {
            "model": "RandomForestClassifier",
            "training_samples": len(customers),
            "accuracy": round(report["accuracy"], 4),
            "feature_importances": importances,
        }

    def predict_churn(self, customers: pd.DataFrame) -> pd.DataFrame:
        """Return customers with churn probability scores."""
        if self._churn_model is None:
            self.train_churn_model(customers)

        features = ["age", "tenure_months", "monthly_spend",
                    "support_tickets", "last_login_days"]
        X = self._churn_scaler.transform(customers[features].values)
        probs = self._churn_model.predict_proba(X)[:, 1]

        result = customers[["customer_id", "name", "monthly_spend"]].copy()
        result["churn_probability"] = np.round(probs, 4)
        result["risk_level"] = result["churn_probability"].apply(
            lambda p: "HIGH" if p >= CHURN_RISK_THRESHOLD else
                      "MEDIUM" if p >= 0.3 else "LOW"
        )
        result["annual_revenue_at_risk"] = (
            result["monthly_spend"] * result["churn_probability"] * 12
        ).round(2)
        return result.sort_values("churn_probability", ascending=False)

    # ── Fraud Scoring ───────────────────────────────────────────────────────

    def train_fraud_model(self, transactions: pd.DataFrame) -> dict:
        """
        Train Isolation Forest on transaction amounts.
        In production: add country encoding, velocity features, etc.
        """
        X = transactions[["amount"]].values
        self._fraud_scaler = StandardScaler()
        X_scaled = self._fraud_scaler.fit_transform(X)

        self._fraud_model = IsolationForest(
            contamination=0.15, random_state=42, n_estimators=100
        )
        self._fraud_model.fit(X_scaled)

        return {
            "model": "IsolationForest",
            "training_samples": len(transactions),
            "contamination": 0.15,
        }

    def score_fraud(self, transactions: pd.DataFrame) -> pd.DataFrame:
        """Return transactions with anomaly scores (-1 = outlier)."""
        if self._fraud_model is None:
            self.train_fraud_model(transactions)

        X = self._fraud_scaler.transform(transactions[["amount"]].values)
        scores = self._fraud_model.decision_function(X)   # higher = more normal
        preds = self._fraud_model.predict(X)              # -1 = anomaly

        result = transactions.copy()
        result["anomaly_score"] = np.round(scores, 4)
        result["ml_fraud_flag"] = (preds == -1).astype(int)
        return result.sort_values("anomaly_score")

    # ── Demand Forecast ─────────────────────────────────────────────────────

    def demand_forecast(self, customers: pd.DataFrame, months: int = 6) -> dict:
        """
        Simple trend projection using mean spend × active base.
        Replace with Prophet / LSTM in production.
        """
        active = customers[customers["churned"] == 0]
        base_mrr = active["monthly_spend"].sum()
        growth_rate = 0.03   # assumed 3% MoM growth (configurable)
        churn_rate = 0.07    # assumed 7% MoM churn (configurable)

        projections = []
        mrr = base_mrr
        for m in range(1, months + 1):
            mrr = mrr * (1 + growth_rate - churn_rate)
            projections.append({
                "month": m,
                "projected_mrr": round(mrr, 2),
                "delta_vs_current": round(mrr - base_mrr, 2),
            })

        return {
            "base_mrr": round(base_mrr, 2),
            "active_customers": len(active),
            "growth_rate_assumed": growth_rate,
            "churn_rate_assumed": churn_rate,
            "projections": projections,
        }
