"""
agents/analysis_agent.py — Trend analysis, anomaly detection, forecasting.
"""
import numpy as np
import pandas as pd
from config import FRAUD_AMOUNT_THRESHOLD, HIGH_RISK_COUNTRIES


class AnalysisAgent:
    """
    Performs statistical analysis on DataFrames produced by DataAgent.
    No LLM calls — pure analytical logic.
    """

    # ── Anomaly Detection ───────────────────────────────────────────────────

    def detect_transaction_anomalies(self, transactions: pd.DataFrame) -> dict:
        """
        Flags anomalies using:
          1. Amount z-score (>2 std devs above mean)
          2. High-risk country + high amount
          3. Already-flagged field
        Returns a summary dict with flagged rows.
        """
        df = transactions.copy()

        mean_amt = df["amount"].mean()
        std_amt = df["amount"].std()

        df["z_score"] = (df["amount"] - mean_amt) / (std_amt if std_amt else 1)
        df["amount_anomaly"] = df["z_score"] > 2.0
        df["country_risk"] = df["country"].isin(HIGH_RISK_COUNTRIES)
        df["high_value_foreign"] = (
            (df["amount"] > FRAUD_AMOUNT_THRESHOLD) & df["country_risk"]
        )

        anomalies = df[
            df["amount_anomaly"] | df["high_value_foreign"] | (df["flagged"] == 1)
        ].copy()

        return {
            "total_transactions": len(df),
            "anomaly_count": len(anomalies),
            "total_at_risk_amount": round(anomalies["amount"].sum(), 2),
            "anomalies": anomalies[[
                "transaction_id", "customer_id", "date", "amount",
                "country", "flagged", "z_score", "high_value_foreign"
            ]].to_dict("records"),
        }

    # ── Trend Analysis ──────────────────────────────────────────────────────

    def spend_trend(self, customers: pd.DataFrame) -> dict:
        """Segment customers by spend tier and compute distribution."""
        df = customers.copy()
        bins = [0, 100, 200, 400, float("inf")]
        labels = ["<$100", "$100-200", "$200-400", ">$400"]
        df["spend_tier"] = pd.cut(df["monthly_spend"], bins=bins, labels=labels)
        dist = df.groupby("spend_tier", observed=True)["customer_id"].count().to_dict()
        return {
            "spend_distribution": dist,
            "avg_spend": round(df["monthly_spend"].mean(), 2),
            "median_spend": round(df["monthly_spend"].median(), 2),
            "top_spender": df.loc[df["monthly_spend"].idxmax(), "name"],
        }

    # ── Forecasting ─────────────────────────────────────────────────────────

    def forecast_revenue(self, customers: pd.DataFrame, months_ahead: int = 3) -> dict:
        """
        Simple linear extrapolation based on current MRR and historical churn rate.
        In production, replace with ARIMA / Prophet.
        """
        active = customers[customers["churned"] == 0]
        mrr = active["monthly_spend"].sum()
        churn_rate = customers["churned"].mean()  # historical churn %

        forecast = []
        current_mrr = mrr
        for m in range(1, months_ahead + 1):
            current_mrr *= (1 - churn_rate)
            forecast.append({
                "month": m,
                "expected_mrr": round(current_mrr, 2),
                "expected_churn_loss": round(mrr - current_mrr, 2),
            })

        return {
            "current_mrr": round(mrr, 2),
            "historical_churn_rate": round(churn_rate, 4),
            "forecast": forecast,
        }
