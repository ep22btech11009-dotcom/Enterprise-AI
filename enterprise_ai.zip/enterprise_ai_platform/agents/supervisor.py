"""
agents/supervisor.py — Orchestrator that routes queries to the right agents.

Uses OpenAI function calling (parallel_tool_calls) so GPT-4o decides
which agents to invoke, then hands results to InsightAgent for synthesis.
"""
import json
from openai import OpenAI
from config import OPENAI_API_KEY, MODEL, MAX_TOKENS
from agents.data_agent import DataAgent
from agents.analysis_agent import AnalysisAgent
from agents.ml_agent import MLAgent
from agents.roi_agent import ROIAgent
from agents.insight_agent import InsightAgent
from rag.rag_engine import RAGEngine


# ── Tool / function definitions for OpenAI ─────────────────────────────────

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "fetch_data_summary",
            "description": "Get a summary of all customer and transaction data.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "detect_anomalies",
            "description": "Run anomaly detection on transactions to find fraud patterns.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "predict_churn",
            "description": "Train a churn model and predict at-risk customers with probabilities.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "forecast_revenue",
            "description": "Forecast revenue and MRR for the next N months.",
            "parameters": {
                "type": "object",
                "properties": {
                    "months": {
                        "type": "integer",
                        "description": "Number of months to forecast (default 3).",
                    }
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "query_documents",
            "description": "Search enterprise SOPs, policies, and reports using RAG.",
            "parameters": {
                "type": "object",
                "properties": {
                    "question": {
                        "type": "string",
                        "description": "The specific question to answer from documents.",
                    }
                },
                "required": ["question"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "compute_roi",
            "description": "Quantify revenue impact, cost savings, and risk reduction.",
            "parameters": {
                "type": "object",
                "properties": {
                    "roi_type": {
                        "type": "string",
                        "enum": ["churn", "fraud"],
                        "description": "Which ROI calculation to run.",
                    }
                },
                "required": ["roi_type"],
            },
        },
    },
]

SYSTEM_PROMPT = (
    "You are a supervisor AI agent for an enterprise analytics platform. "
    "Your job is to answer the user's business question by calling the "
    "available tools. Call ALL tools that are relevant to fully answer the query. "
    "After all tools have been called and results are available, respond with DONE."
)


class SupervisorAgent:
    """
    Orchestrates the full pipeline using OpenAI function calling.
    GPT-4o decides which agents to call based on the user query.
    """

    def __init__(self, use_rag: bool = True):
        print("\n[Supervisor] Initialising agents...")
        self._data = DataAgent()
        self._analysis = AnalysisAgent()
        self._ml = MLAgent()
        self._roi = ROIAgent()
        self._insight = InsightAgent()
        self._rag = None
        self._use_rag = use_rag

        if use_rag:
            try:
                self._rag = RAGEngine()
            except Exception as e:
                print(f"  [Supervisor] RAG disabled: {e}")
                self._use_rag = False

        self._client = OpenAI(api_key=OPENAI_API_KEY)

        # Cached results filled during a run
        self._churn_df = None
        self._anomalies = None

    # ── Tool execution ─────────────────────────────────────────────────────

    def _execute_tool(self, name: str, inputs: dict) -> str:
        customers = self._data.get_all_customers()
        transactions = self._data.get_all_transactions()

        if name == "fetch_data_summary":
            return json.dumps(self._data.summary())

        elif name == "detect_anomalies":
            result = self._analysis.detect_transaction_anomalies(transactions)
            self._anomalies = result.get("anomalies", [])
            result_copy = dict(result)
            result_copy.pop("anomalies", None)
            result_copy["sample_anomalies"] = self._anomalies[:3]
            return json.dumps(result_copy)

        elif name == "predict_churn":
            self._ml.train_churn_model(customers)
            churn_df = self._ml.predict_churn(customers)
            self._churn_df = churn_df.to_dict("records")
            high = [c for c in self._churn_df if c["risk_level"] == "HIGH"]
            return json.dumps({
                "total_customers": len(self._churn_df),
                "high_risk": len(high),
                "sample_high_risk": high[:5],
            })

        elif name == "forecast_revenue":
            months = inputs.get("months", 3)
            result = self._analysis.forecast_revenue(customers, months_ahead=months)
            return json.dumps(result)

        elif name == "query_documents":
            if not self._use_rag or self._rag is None:
                return "RAG not available. LlamaIndex packages may not be installed."
            answer = self._rag.query(inputs.get("question", ""))
            return answer

        elif name == "compute_roi":
            roi_type = inputs.get("roi_type", "churn")
            if roi_type == "churn":
                if self._churn_df is None:
                    self._ml.train_churn_model(customers)
                    self._churn_df = self._ml.predict_churn(customers).to_dict("records")
                roi = self._roi.quantify_churn_roi(self._churn_df)
            else:
                if self._anomalies is None:
                    result = self._analysis.detect_transaction_anomalies(transactions)
                    self._anomalies = result.get("anomalies", [])
                roi = self._roi.quantify_fraud_roi(self._anomalies)
            return json.dumps(roi)

        return f"Unknown tool: {name}"

    # ── Main run loop ──────────────────────────────────────────────────────

    def run(self, user_query: str) -> str:
        """Execute the full agentic pipeline and return the final insight."""
        print(f"\n[Supervisor] Query: {user_query}")
        print("[Supervisor] Calling GPT-4o to plan agent tasks...\n")

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_query},
        ]
        collected_results: dict = {}

        # ── Agentic loop ──────────────────────────────────────────────────
        while True:
            response = self._client.chat.completions.create(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                tools=TOOLS,
                tool_choice="auto",
                messages=messages,
            )

            msg = response.choices[0].message
            finish_reason = response.choices[0].finish_reason

            # Append assistant message to history
            messages.append(msg)

            # No tool calls → model is done
            if finish_reason == "stop" or not msg.tool_calls:
                break

            # Execute every tool call in this turn (GPT-4o may batch several)
            for tool_call in msg.tool_calls:
                fn_name = tool_call.function.name
                fn_args = json.loads(tool_call.function.arguments or "{}")
                print(f"  → Calling tool: {fn_name} | inputs: {fn_args}")

                result = self._execute_tool(fn_name, fn_args)
                collected_results[fn_name] = result

                # Return result to the model
                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result,
                })

        # ── Synthesize final insight ───────────────────────────────────────
        print("\n[Supervisor] All tools executed. Generating final insight...\n")

        rag_context = collected_results.get("query_documents")
        roi_raw = collected_results.get("compute_roi")
        roi_dict = json.loads(roi_raw) if roi_raw else None

        narrative = (
            self._roi.generate_roi_narrative(roi_dict, context=user_query)
            if roi_dict else None
        )

        final_insight = self._insight.synthesize(
            query=user_query,
            data_summary=json.loads(collected_results.get("fetch_data_summary", "null")),
            analysis_results=json.loads(
                collected_results.get("detect_anomalies", "null") or "null"
            ),
            ml_results=json.loads(
                collected_results.get("predict_churn", "null") or "null"
            ),
            rag_context=rag_context,
            roi_results=roi_dict,
        )

        if narrative:
            return f"{final_insight}\n\n── ROI Summary ──\n{narrative}"
        return final_insight
